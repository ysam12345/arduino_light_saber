/*
 This file is part of the Universal Saber library.

 The Universal Saber library is free software: you can redistribute it
 and/or modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation, either version 3 of the License,
 or (at your option) any later version.

 The Universal Saber library is distributed in the hope that it will be
 useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with the Universal Saber library.  If not, see <http://www.gnu.org/licenses/>.
 */
/*
 * USaberConfig.h
 *
 *  This file is to be included in certain "heavy weight" features of the
 *  Universal Saber library so that they can be optionally excluded from the
 *  build. The code in certain files is #ifdef wrapped such that they contain
 *  no code or only "Light Weight" code unless their corresponding BUILD_XXX
 *  #define exists.
 *
 *  To remove a feature and prevent it from building, simply comment out the
 *  corresponding #define for the feature.
 *
 *  The reason this is necessary is that some of the libraries introduce
 *  declarations that allocate static or global memory or inflate the compiled
 *  hex file size regardless of if the feature is actually used. Not only is
 *  this is an unnecessary waste of resources, it may also introduce
 *  incompatibility with certain MCUs such as the ATTiny chips which don't
 *  support I2C or Wire.
 *
 *	Note that features that do not perform these kinds of "Heavy" actions are
 *	always included as they cost little or nothing in the way of RAM or
 *	compiled hex file size unless they are actually used.
 *
 *	For now, all features are enabled by default.
 *
 *  Created on: Jun 24, 2016
 *      Author: JakeSoft
 */

#ifndef _USABER_USABERCONFIG_H_
#define _USABER_USABERCONFIG_H_

//Comment out the line for which you'd like to exclude the corresponding feature

/**
 * Build the MPU6050MotionManager.
 * Note: This requires that I2CDEV also be enabled below.
 */
#define BUILD_MPU6050

/**
 * Build the MPU6050LiteMotionManager and MPU6050AdvancedMotionManager.
 * Note: This requires the Wire library (included by default with Arduino IDE)
 */
#define BUILD_MPU6050LITE

/**
 * Build USaber's built-in I2CDev library.
 * Note: This requires that Wire also be included in the sketch.
 */
#define BUILD_I2CDEV

/**
 * Try to automatically include the Wire library.
 * Note: This may not work for older versions of the Arduino IDE.
 */
#define AUTO_INCLUDE_WIRE

#endif /* _USABER_USABERCONFIG_H_ */
